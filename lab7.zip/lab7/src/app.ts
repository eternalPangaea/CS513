import * as express from "express";
import * as bodyParser from "body-parser";
const configRoutes = require("./routes");

class App {

  constructor() {
    this.app = express();
    this.config();
    this.routes();
  }

  public app: express.Application;

  private config(): void {
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: false }));
    this.app.use(function(req, res, next) {
        console.log("--------------First Log---------------")
        console.log(
          "Now the request is made to url: "+req.originalUrl);
        console.log(
            "And its request body is " + JSON.stringify(req.body));
        console.log(
            "And its Http verb is " + req.method);
        next();
      });
    const pathsAccessed = {};
    this.app.use(function(req, res, next) {
        console.log("--------------Second Log---------------")
        if (!pathsAccessed[req.originalUrl]) pathsAccessed[req.originalUrl] = 0;
        pathsAccessed[req.originalUrl]++;
        for (const [key, value] of Object.entries(pathsAccessed)) {
            console.log("There have now been "+value +" requests made to " +key);
        }
        next();
      });
  }

  private routes(): void {
    const router = express.Router();

    configRoutes(this.app);

  }

}

export default new App().app; 