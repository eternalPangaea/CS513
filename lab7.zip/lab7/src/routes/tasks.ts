const express = require("express");
const router = express.Router();
const data = require("../data");
//const taskData = new data.tasks();
const taskData = data.tasks;

router.get("/tasks", async (req, res) => {
  try {
   	const taskList = await taskData.getAllTasks();
   	const result = [];
   	var skip = 0;
   	var take = 20;
	if (req.query.skip)
		skip = req.query.skip;
	if(req.query.take)
		take = req.query.take;
    if (skip > taskList.length) throw "You can let skipped number more than the total number!";
    if (skip < 0 || take < 0) throw "Skip and take cannot be negative number!";
    if (take > 100) throw "Take should be less than or equal 100!";
    for(let i = skip; i < taskList.length; i++){
    	if(take == 0){
    		break;
    	}
    	result.push(taskList[i]);
    	take--;
   	}

   	res.json(result);
  } catch (e) {
   	res.status(500).json({ error: e });
  }
});

router.get("/tasks/:id", async (req, res) => {
  try {
    const task = await taskData.getTaskById(req.params.id);
    res.json(task);
  } catch (e) {
    res.status(404).json({ error: "Task is not found!" });
  }
});

router.post("/tasks", async (req, res) => {
  const newTaskData = req.body;
  try {
  	if (Object.keys(newTaskData).length > 5) throw "task should have five fields, remove the unmeaningful attributes!";
    if (typeof newTaskData.title !== "string") throw "Please provide a vaild title!";
	if (typeof newTaskData.description !== "string") throw "No valid description!";
	if (typeof newTaskData.hoursEstimated !== "number") throw "No valid hoursEstimated!";
	if (typeof newTaskData.completed !== "boolean") throw "No valid siganal of 'completed'!";
	if (!Array.isArray(newTaskData.comments)) throw "No valid comments!";
	for(let i = 0; i < newTaskData.comments.length; i++){
	   	if(typeof newTaskData.comments[i].name !== "string") throw "No comments' name provided!";
    	if(typeof newTaskData.comments[i].comment !== "string") throw "No comments' comment provided!";
    	if(Object.keys(newTaskData.comments[i]).length>2) throw "comments should have two fields!";
    }
    const newTask = await taskData.addTask(newTaskData.title, newTaskData.description, newTaskData.hoursEstimated, 
    				newTaskData.completed, newTaskData.comments)
    if(!newTask)
    	throw "Server is busy...!"
    else
    	res.json(newTask);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

router.put("/tasks/:id", async (req, res) => {
  const updatedData = req.body;
  try{ 
    const existedTask = await taskData.getTaskById(req.params.id);
  } catch(e){
    res.status(404).json({ error: "Task is not found!" });
    return;
  }
  try {
  	if (typeof updatedData.title !== "string") throw "No vaild title!";
    if (typeof updatedData.description !== "string") throw "No valid description!";
	if (typeof updatedData.hoursEstimated !== "number") throw "No valid hoursEstimated!";
	if (typeof updatedData.completed !== "boolean") throw "No valid siganal of 'completed'!";
	if (updatedData.comments) throw "You cann't do any opperations on comments, please remove it!";
	if(Object.keys(updatedData).length > 4) throw "There must be four fields for updating tasks, remove the unmeaningful attributes!";
    const updatedTask = await taskData.updateTask(req.params.id, updatedData);
    res.json(updatedTask);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});


router.patch("/tasks/:id", async (req, res) => {
  const updatedData = req.body;
  try {
    const existedTask = await taskData.getTaskById(req.params.id);
  } catch (e) {
    res.status(404).json({ error: "Task is not found!"});
    return;
  }
  try {
  	if (Object.keys(updatedData).length == 0) throw "Seems like you didn't do any change!";
  	Object.keys(updatedData).forEach(function(property) {
    	if(property != "title" && property != "description" && property != "hoursEstimated" && property != "completed" && property != "comments")
  			throw "The property that you try to change is not allowed!";
	});

    if (updatedData.title) {
        if (typeof updatedData.title !== "string") throw "No vaild title!";
    }
    if (updatedData.description) {
        if (typeof updatedData.description !== "string") throw "No vaild description!";
    }
    if (updatedData.hoursEstimated) {
        if (typeof updatedData.hoursEstimated !== "number") throw "No vaild hoursEstimated!";
    }
    if (updatedData.completed) {
        if (typeof updatedData.completed !== "boolean") throw "No vaild completed!";
    }
    if (updatedData.comments) throw "You cann't do any opperations on comments, please remove it!";

    const updatedTask = await taskData.updateTaskByPatch(req.params.id, updatedData);
    res.json(updatedTask);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});


router.post("/tasks/:id/comments", async (req, res) => {
  const updatedData = req.body;
  try{ 
    const existedTask = await taskData.getTaskById(req.params.id);
  } catch(e){
    res.status(404).json({ error: "Task is not found!" });
    return;
  }
  try {
  	if (typeof updatedData.name !== "string") throw "No vaild name!";
    if (typeof updatedData.comment !== "string") throw "No valid comment!";
    if (updatedData._id) throw "You cann't provide comments' id";
    if(Object.keys(updatedData).length > 2) throw "There must be two fields for posting a new comment, remove the unmeaningful attributes!";

	const updatedTask = await taskData.addComment(req.params.id, updatedData.name, updatedData.comment);
    res.json(updatedTask);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

router.delete("/tasks/:taskId/:commentId", async (req, res) => {
  try{ 
    const existedTask = await taskData.getTaskById(req.params.taskId);
  } catch(e){
    res.status(404).json({ error: "Task is not found!" });
    return;
  }
  try {
	const updatedTask = await taskData.deleteComment(req.params.taskId, req.params.commentId);
    res.json(updatedTask);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});



module.exports = router;







