const taskData1 = require("./tasks");

module.exports = {
	tasks: taskData1
}