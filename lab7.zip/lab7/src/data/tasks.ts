const mongoCollections = require("../config/mongoCollections");
const tasks = mongoCollections.tasks;
const uuid = require("uuid/v4");

const exportedMethods = {
	async getAllTasks(){
		const taskCollection = await tasks();
		let taskLists = await taskCollection.find({}).toArray();
		let result = [];
		for(let i = 0; i < taskLists.length; i++){
			let temp ={"_id":taskLists[i]._id,"title":taskLists[i].title};
			result.push(temp);
		}
		return result;
	},

	async getTaskById(id){
		const taskCollection = await tasks();
		const task = await taskCollection.findOne({_id: id});
		if(!task) throw "Task is not found";
		return task;
	},

	async addTask(title, description, hoursEstimated, completed, comments){
		if (typeof title !== "string") throw "Please provide a vaild title";
		if (typeof description !== "string") throw "No valid description";
		if (typeof hoursEstimated !== "number") throw "No valid hoursEstimated";
		if (typeof completed !== "boolean") throw "No valid siganal of 'completed'";
	    if (!Array.isArray(comments)) throw "No valid comments";
	    for(let i = 0; i < comments.length; i++){
	     	if(Object.keys(comments[i]).length>2) throw "comments should have two fields";
	     	if(typeof comments[i].name !== "string") throw "No comments' name provided";
	     	if(typeof comments[i].comment !== "string") throw "No comments' comment provided";
	     	if(comments[i]._id) throw "You cann't provide comments' id";
	     	else
	     		comments[i] = Object.assign({_id:uuid()},comments[i]);
	    }

	    const taskCollection = await tasks();
	    const newTask = {
	    	_id: uuid(),
	    	title: title,
	    	description: description, 
	    	hoursEstimated: hoursEstimated,
	    	completed: completed,
	    	comments: comments
	    };

	    const newTaskInfo = await taskCollection.insertOne(newTask);
	    if(!newTaskInfo)
	    	throw "Server is busy..."
    	return newTask;
	},

	async updateTask(id, updatedTask) {
	    const taskCollection = await tasks();
	    const updatedTaskData = {title:String,description:String,hoursEstimated:Number,completed:Boolean,comments:Array};
	   
	    if (typeof updatedTask.title !== "string") throw "No vaild title";
			if (typeof updatedTask.description !== "string") throw "No valid description";
			if (typeof updatedTask.hoursEstimated !== "number") throw "No valid hoursEstimated";
			if (typeof updatedTask.completed !== "boolean") throw "No valid siganal of 'completed'";
	    if (updatedTask.comments) throw "You cann't do any opperations on comments";

	    updatedTaskData.title = updatedTask.title;
	    updatedTaskData.description = updatedTask.description;
	    updatedTaskData.hoursEstimated = updatedTask.hoursEstimated;
	    updatedTaskData.completed = updatedTask.completed;
	    const oldTask = await this.getTaskById(id);
	    updatedTaskData.comments = oldTask.comments;

	    let updateCommand = {
	      $set: updatedTaskData
	    };
	    const query = {
	      _id: id
	    };
	    await taskCollection.updateOne(query, updateCommand);
	    return await this.getTaskById(id);
  	},

  	async updateTaskByPatch(id, updatedTask) {
		const taskCollection = await tasks();
	    const updatedTaskData = {title:String,description:String,hoursEstimated:Number,completed:Boolean};
	    const oldTask = await this.getTaskById(id);

	    if (updatedTask.comments) throw "You cann't do any opperations on comments";
	    if (updatedTask.title) {
	      if (typeof updatedTask.title !== "string") throw "No vaild title";
	      updatedTaskData.title = updatedTask.title;
	    }
	    else
	    	updatedTaskData.title = oldTask.title

	    if (updatedTask.description) {
	      if (typeof updatedTask.description !== "string") throw "No vaild description";
	      updatedTaskData.description = updatedTask.description;
	    }
	    else
	    	updatedTaskData.description = oldTask.description

	    if (updatedTask.hoursEstimated) {
	      if (typeof updatedTask.hoursEstimated !== "number") throw "No vaild hoursEstimated";
	      updatedTaskData.hoursEstimated = updatedTask.hoursEstimated;
	    }
	    else
	    	updatedTaskData.hoursEstimated = oldTask.hoursEstimated

	    if (updatedTask.completed) {
	      if (typeof updatedTask.completed  !== "boolean") throw "No vaild completed";
	      updatedTaskData.completed = updatedTask.completed;
	    }
	    else
	    	updatedTaskData.completed = oldTask.completed

	    let updateCommand = {
	      $set: updatedTaskData
	    };
	    const query = {
	      _id: id
	    };
	    await taskCollection.updateOne(query, updateCommand);
	    return await this.getTaskById(id);
	},

	async addComment(t_id, name, comment){
	    const oldTask = await this.getTaskById(t_id);
	    if(!oldTask) throw "Task is not found";
		if (typeof name !== "string") throw "No vaild name";
		if (typeof comment !== "string") throw "No vaild comment";
		const taskCollection = await tasks();
		const new_comment = {
			_id: uuid(),
			name: name,
			comment: comment
		}
		oldTask.comments.push(new_comment);
		let updateCommand = {
	      $set: oldTask
	    };
	    const query = {
	      _id: t_id
	    };
	    await taskCollection.updateOne(query, updateCommand);
	    return await this.getTaskById(t_id);
	},

	async deleteComment(t_id, c_id){
		const taskCollection = await tasks();
		const existedTask = await this.getTaskById(t_id);
		if(!existedTask) throw "Task is not found";
		var check = 0;
		for(var i in existedTask.comments){
			//console.log(existedTask.comments[i]._id);
			if(existedTask.comments[i]._id == c_id){
				var index = i;
				check = 1;
			}
		}
		if(check === 0)
			throw "This comment id is not vaild"
		existedTask.comments.splice(index,1);
		let updateCommand = {
	      $set: existedTask
	    };
	    const query = {
	      _id: t_id
	    };
		await taskCollection.updateOne(query, updateCommand);
	    return await this.getTaskById(t_id);
	}

}

module.exports = exportedMethods;







